import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Library, GraduationCap, ShieldCheck, BookOpen, Users, BarChart3 } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <Library className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold text-foreground">LibraryHub</span>
          </div>
          <nav className="hidden items-center gap-6 md:flex">
            <Link href="#features" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Features
            </Link>
            <Link href="#about" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              About
            </Link>
          </nav>
          <div className="flex items-center gap-3">
            <Button variant="ghost" asChild>
              <Link href="/login">Sign In</Link>
            </Button>
            <Button asChild>
              <Link href="/signup">Get Started</Link>
            </Button>
          </div>
        </div>
      </header>

      <main>
        <section className="container mx-auto px-4 py-24 text-center">
          <div className="mx-auto max-w-3xl space-y-6">
            <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
              <BookOpen className="h-4 w-4" />
              University Library Management System
            </div>
            <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl lg:text-6xl text-balance">
              Manage Your Library with Ease
            </h1>
            <p className="text-lg text-muted-foreground text-pretty">
              A modern, intuitive library management system designed for universities and colleges. Track books, manage
              students, and streamline your library operations.
            </p>
            <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Button size="lg" asChild>
                <Link href="/login">
                  <ShieldCheck className="mr-2 h-5 w-5" />
                  Admin Login
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/login?type=student">
                  <GraduationCap className="mr-2 h-5 w-5" />
                  Student Login
                </Link>
              </Button>
            </div>
          </div>
        </section>

        <section id="features" className="border-t bg-muted/30 py-24">
          <div className="container mx-auto px-4">
            <div className="mb-12 text-center">
              <h2 className="text-3xl font-bold text-foreground">Powerful Features</h2>
              <p className="mt-2 text-muted-foreground">Everything you need to manage your library efficiently</p>
            </div>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader>
                  <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                    <BookOpen className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>Book Management</CardTitle>
                  <CardDescription>Add, edit, and organize your entire book collection with ease</CardDescription>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader>
                  <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-accent/10">
                    <Users className="h-6 w-6 text-accent" />
                  </div>
                  <CardTitle>Student Management</CardTitle>
                  <CardDescription>Track student registrations and their borrowing history</CardDescription>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader>
                  <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-chart-3/10">
                    <BarChart3 className="h-6 w-6 text-chart-3" />
                  </div>
                  <CardTitle>Reports & Analytics</CardTitle>
                  <CardDescription>Generate detailed reports and track library performance</CardDescription>
                </CardHeader>
              </Card>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t py-8">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>© 2025 LibraryHub. Built for academic purposes.</p>
        </div>
      </footer>
    </div>
  )
}
