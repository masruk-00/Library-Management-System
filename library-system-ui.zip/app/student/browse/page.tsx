"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Search, BookOpen, User, Calendar, Hash, Layers } from "lucide-react"
import { books, categories, type Book } from "@/lib/data"

export default function BrowseBooksPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [selectedBook, setSelectedBook] = useState<Book | null>(null)

  const filteredBooks = books.filter((book) => {
    const matchesSearch =
      book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.author.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = categoryFilter === "all" || book.category === categoryFilter
    return matchesSearch && matchesCategory
  })

  return (
    <div className="min-h-screen">
      <Header title="Browse Books" />

      <main className="p-6">
        <div className="mb-6 flex flex-col gap-4 sm:flex-row">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search by title or author..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-full sm:w-48">
              <SelectValue placeholder="All Categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map((cat) => (
                <SelectItem key={cat} value={cat}>
                  {cat}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filteredBooks.map((book) => (
            <Card key={book.id} className="overflow-hidden transition-shadow hover:shadow-lg">
              <CardContent className="p-0">
                <div className="flex h-40 items-center justify-center bg-muted">
                  <BookOpen className="h-16 w-16 text-muted-foreground/50" />
                </div>
                <div className="p-4">
                  <h3 className="line-clamp-1 font-semibold">{book.title}</h3>
                  <p className="text-sm text-muted-foreground">{book.author}</p>
                  <div className="mt-3 flex items-center justify-between">
                    <Badge variant={book.available > 0 ? "secondary" : "outline"}>
                      {book.available > 0 ? `${book.available} available` : "Unavailable"}
                    </Badge>
                    <Button variant="ghost" size="sm" onClick={() => setSelectedBook(book)}>
                      Details
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredBooks.length === 0 && (
          <div className="py-12 text-center text-muted-foreground">
            <BookOpen className="mx-auto mb-4 h-16 w-16 opacity-50" />
            <p className="text-lg">No books found</p>
            <p className="text-sm">Try adjusting your search or filter criteria</p>
          </div>
        )}

        <Dialog open={!!selectedBook} onOpenChange={() => setSelectedBook(null)}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>{selectedBook?.title}</DialogTitle>
            </DialogHeader>
            {selectedBook && (
              <div className="space-y-4">
                <div className="flex h-48 items-center justify-center rounded-lg bg-muted">
                  <BookOpen className="h-20 w-20 text-muted-foreground/50" />
                </div>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">
                      <span className="text-muted-foreground">Author:</span> {selectedBook.author}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Layers className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">
                      <span className="text-muted-foreground">Category:</span> {selectedBook.category}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Hash className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">
                      <span className="text-muted-foreground">ISBN:</span> {selectedBook.isbn}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">
                      <span className="text-muted-foreground">Published:</span> {selectedBook.publishedYear}
                    </span>
                  </div>
                </div>
                {selectedBook.description && (
                  <p className="text-sm text-muted-foreground">{selectedBook.description}</p>
                )}
                <div className="flex items-center justify-between pt-4">
                  <Badge variant={selectedBook.available > 0 ? "default" : "destructive"}>
                    {selectedBook.available > 0
                      ? `${selectedBook.available} of ${selectedBook.quantity} available`
                      : "Currently unavailable"}
                  </Badge>
                  <Button disabled={selectedBook.available === 0}>Request Book</Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </main>
    </div>
  )
}
