"use client"

import { Header } from "@/components/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, BookCopy, CheckCircle, AlertTriangle, Calendar } from "lucide-react"
import { issuedBooks, books } from "@/lib/data"

export default function MyBooksPage() {
  const currentStudentId = "1"
  const studentIssues = issuedBooks
    .filter((i) => i.studentId === currentStudentId)
    .map((i) => ({
      ...i,
      book: books.find((b) => b.id === i.bookId),
    }))

  const activeBooks = studentIssues.filter((i) => i.status === "issued")
  const overdueBooks = studentIssues.filter((i) => i.status === "overdue")
  const returnedBooks = studentIssues.filter((i) => i.status === "returned")

  const getDaysRemaining = (dueDate: string) => {
    const due = new Date(dueDate)
    const today = new Date()
    const diff = Math.ceil((due.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
    return diff
  }

  return (
    <div className="min-h-screen">
      <Header title="My Books" />

      <main className="p-6">
        <div className="mb-6 grid gap-4 sm:grid-cols-3">
          <Card>
            <CardContent className="flex items-center gap-4 p-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                <BookCopy className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{activeBooks.length}</p>
                <p className="text-sm text-muted-foreground">Currently Borrowed</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex items-center gap-4 p-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-destructive/10">
                <AlertTriangle className="h-6 w-6 text-destructive" />
              </div>
              <div>
                <p className="text-2xl font-bold">{overdueBooks.length}</p>
                <p className="text-sm text-muted-foreground">Overdue</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex items-center gap-4 p-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-success/10">
                <CheckCircle className="h-6 w-6 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold">{returnedBooks.length}</p>
                <p className="text-sm text-muted-foreground">Returned</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Book History</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="active">
              <TabsList>
                <TabsTrigger value="active">Active ({activeBooks.length})</TabsTrigger>
                <TabsTrigger value="overdue">Overdue ({overdueBooks.length})</TabsTrigger>
                <TabsTrigger value="returned">Returned ({returnedBooks.length})</TabsTrigger>
              </TabsList>

              <TabsContent value="active" className="mt-4">
                {activeBooks.length > 0 ? (
                  <div className="space-y-4">
                    {activeBooks.map((issue) => {
                      const daysLeft = getDaysRemaining(issue.dueDate)
                      return (
                        <div key={issue.id} className="flex items-center justify-between rounded-lg border p-4">
                          <div className="flex items-center gap-4">
                            <div className="flex h-14 w-14 items-center justify-center rounded-lg bg-muted">
                              <BookOpen className="h-7 w-7 text-muted-foreground" />
                            </div>
                            <div>
                              <p className="font-medium">{issue.book?.title}</p>
                              <p className="text-sm text-muted-foreground">{issue.book?.author}</p>
                              <div className="mt-1 flex items-center gap-2 text-sm text-muted-foreground">
                                <Calendar className="h-3 w-3" />
                                Issued: {issue.issueDate}
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <Badge variant={daysLeft <= 3 ? "secondary" : "default"}>{daysLeft} days left</Badge>
                            <p className="mt-1 text-sm text-muted-foreground">Due: {issue.dueDate}</p>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                ) : (
                  <div className="py-8 text-center text-muted-foreground">No active books</div>
                )}
              </TabsContent>

              <TabsContent value="overdue" className="mt-4">
                {overdueBooks.length > 0 ? (
                  <div className="space-y-4">
                    {overdueBooks.map((issue) => (
                      <div
                        key={issue.id}
                        className="flex items-center justify-between rounded-lg border border-destructive/20 bg-destructive/5 p-4"
                      >
                        <div className="flex items-center gap-4">
                          <div className="flex h-14 w-14 items-center justify-center rounded-lg bg-destructive/10">
                            <AlertTriangle className="h-7 w-7 text-destructive" />
                          </div>
                          <div>
                            <p className="font-medium">{issue.book?.title}</p>
                            <p className="text-sm text-muted-foreground">{issue.book?.author}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge variant="destructive">${issue.fine} fine</Badge>
                          <p className="mt-1 text-sm text-muted-foreground">Due: {issue.dueDate}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="py-8 text-center text-muted-foreground">No overdue books</div>
                )}
              </TabsContent>

              <TabsContent value="returned" className="mt-4">
                {returnedBooks.length > 0 ? (
                  <div className="space-y-4">
                    {returnedBooks.map((issue) => (
                      <div
                        key={issue.id}
                        className="flex items-center justify-between rounded-lg border p-4 opacity-75"
                      >
                        <div className="flex items-center gap-4">
                          <div className="flex h-14 w-14 items-center justify-center rounded-lg bg-muted">
                            <CheckCircle className="h-7 w-7 text-success" />
                          </div>
                          <div>
                            <p className="font-medium">{issue.book?.title}</p>
                            <p className="text-sm text-muted-foreground">{issue.book?.author}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge variant="secondary">Returned</Badge>
                          <p className="mt-1 text-sm text-muted-foreground">{issue.returnDate}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="py-8 text-center text-muted-foreground">No returned books</div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
