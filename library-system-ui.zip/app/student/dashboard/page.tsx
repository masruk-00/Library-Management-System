"use client"

import { Header } from "@/components/header"
import { StatCard } from "@/components/stat-card"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { BookOpen, BookCopy, AlertTriangle, Clock, ArrowRight } from "lucide-react"
import { issuedBooks, books } from "@/lib/data"
import Link from "next/link"

export default function StudentDashboardPage() {
  // Simulating current student's data (student ID: 1)
  const currentStudentId = "1"
  const studentIssues = issuedBooks
    .filter((i) => i.studentId === currentStudentId)
    .map((i) => ({
      ...i,
      book: books.find((b) => b.id === i.bookId),
    }))

  const activeBooks = studentIssues.filter((i) => i.status === "issued" || i.status === "overdue")
  const overdueBooks = studentIssues.filter((i) => i.status === "overdue")
  const returnedBooks = studentIssues.filter((i) => i.status === "returned")

  const recentBooks = books.slice(0, 4)

  return (
    <div className="min-h-screen">
      <Header title="Student Dashboard" />

      <main className="p-6">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-foreground">Welcome back, Alice!</h2>
          <p className="text-muted-foreground">Here's an overview of your library activity</p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard title="Books Borrowed" value={activeBooks.length} icon={BookCopy} iconClassName="bg-primary" />
          <StatCard
            title="Overdue Books"
            value={overdueBooks.length}
            icon={AlertTriangle}
            iconClassName="bg-destructive"
          />
          <StatCard title="Books Returned" value={returnedBooks.length} icon={BookOpen} iconClassName="bg-success" />
          <StatCard title="Total History" value={studentIssues.length} icon={Clock} iconClassName="bg-chart-3" />
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>My Current Books</CardTitle>
              <Button variant="ghost" size="sm" asChild>
                <Link href="/student/my-books">
                  View All
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </CardHeader>
            <CardContent>
              {activeBooks.length > 0 ? (
                <div className="space-y-4">
                  {activeBooks.map((issue) => (
                    <div key={issue.id} className="flex items-center justify-between rounded-lg border p-4">
                      <div className="flex items-center gap-4">
                        <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                          <BookOpen className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium">{issue.book?.title}</p>
                          <p className="text-sm text-muted-foreground">Due: {issue.dueDate}</p>
                        </div>
                      </div>
                      <Badge variant={issue.status === "overdue" ? "destructive" : "default"}>{issue.status}</Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-8 text-center text-muted-foreground">
                  <BookCopy className="mx-auto mb-2 h-12 w-12 opacity-50" />
                  <p>No books currently borrowed</p>
                  <Button variant="outline" className="mt-4 bg-transparent" asChild>
                    <Link href="/student/browse">Browse Books</Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>New Arrivals</CardTitle>
              <Button variant="ghost" size="sm" asChild>
                <Link href="/student/browse">
                  Browse All
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentBooks.map((book) => (
                  <div key={book.id} className="flex items-center gap-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-muted">
                      <BookOpen className="h-6 w-6 text-muted-foreground" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">{book.title}</p>
                      <p className="text-sm text-muted-foreground">{book.author}</p>
                    </div>
                    <Badge variant={book.available > 0 ? "secondary" : "outline"}>
                      {book.available > 0 ? `${book.available} available` : "Unavailable"}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
