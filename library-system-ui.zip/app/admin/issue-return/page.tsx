"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { IssueModal } from "@/components/issue-modal"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Search, Plus, ArrowLeftRight, AlertTriangle, CheckCircle, BookCopy } from "lucide-react"
import { issuedBooks as initialIssuedBooks, books, students, type IssuedBook } from "@/lib/data"

export default function IssueReturnPage() {
  const [transactions, setTransactions] = useState<IssuedBook[]>(initialIssuedBooks)
  const [searchQuery, setSearchQuery] = useState("")
  const [isIssueModalOpen, setIsIssueModalOpen] = useState(false)
  const [returnDialogOpen, setReturnDialogOpen] = useState(false)
  const [selectedTransaction, setSelectedTransaction] = useState<IssuedBook | null>(null)

  const enrichedTransactions = transactions.map((t) => ({
    ...t,
    book: books.find((b) => b.id === t.bookId),
    student: students.find((s) => s.id === t.studentId),
  }))

  const activeIssues = enrichedTransactions.filter((t) => t.status === "issued" || t.status === "overdue")
  const overdueIssues = enrichedTransactions.filter((t) => t.status === "overdue")
  const returnedBooks = enrichedTransactions.filter((t) => t.status === "returned")

  const filteredTransactions = (list: typeof enrichedTransactions) => {
    return list.filter(
      (t) =>
        t.book?.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        t.student?.name.toLowerCase().includes(searchQuery.toLowerCase()),
    )
  }

  const handleIssue = (data: { bookId: string; studentId: string; dueDate: string }) => {
    const newIssue: IssuedBook = {
      id: (transactions.length + 1).toString(),
      bookId: data.bookId,
      studentId: data.studentId,
      issueDate: new Date().toISOString().split("T")[0],
      dueDate: data.dueDate,
      status: "issued",
    }
    setTransactions([newIssue, ...transactions])
  }

  const handleReturn = () => {
    if (selectedTransaction) {
      setTransactions(
        transactions.map((t) =>
          t.id === selectedTransaction.id
            ? { ...t, status: "returned", returnDate: new Date().toISOString().split("T")[0] }
            : t,
        ),
      )
      setReturnDialogOpen(false)
      setSelectedTransaction(null)
    }
  }

  const openReturnDialog = (transaction: IssuedBook) => {
    setSelectedTransaction(transaction)
    setReturnDialogOpen(true)
  }

  const calculateFine = (dueDate: string) => {
    const due = new Date(dueDate)
    const today = new Date()
    const diffDays = Math.ceil((today.getTime() - due.getTime()) / (1000 * 60 * 60 * 24))
    return diffDays > 0 ? diffDays * 5 : 0
  }

  return (
    <div className="min-h-screen">
      <Header title="Issue & Return" />

      <main className="p-6">
        <div className="mb-6 grid gap-4 sm:grid-cols-3">
          <Card>
            <CardContent className="flex items-center gap-4 p-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                <BookCopy className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{activeIssues.length}</p>
                <p className="text-sm text-muted-foreground">Active Issues</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex items-center gap-4 p-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-destructive/10">
                <AlertTriangle className="h-6 w-6 text-destructive" />
              </div>
              <div>
                <p className="text-2xl font-bold">{overdueIssues.length}</p>
                <p className="text-sm text-muted-foreground">Overdue</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex items-center gap-4 p-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-success/10">
                <CheckCircle className="h-6 w-6 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold">{returnedBooks.length}</p>
                <p className="text-sm text-muted-foreground">Returned</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <ArrowLeftRight className="h-5 w-5" />
              Transactions
            </CardTitle>
            <Button onClick={() => setIsIssueModalOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Issue Book
            </Button>
          </CardHeader>
          <CardContent>
            <div className="mb-4">
              <div className="relative max-w-sm">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search by book or student..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>

            <Tabs defaultValue="active">
              <TabsList>
                <TabsTrigger value="active">Active ({activeIssues.length})</TabsTrigger>
                <TabsTrigger value="overdue">Overdue ({overdueIssues.length})</TabsTrigger>
                <TabsTrigger value="returned">Returned ({returnedBooks.length})</TabsTrigger>
              </TabsList>

              <TabsContent value="active" className="mt-4">
                <TransactionTable
                  transactions={filteredTransactions(activeIssues)}
                  onReturn={openReturnDialog}
                  showReturnButton
                />
              </TabsContent>

              <TabsContent value="overdue" className="mt-4">
                <TransactionTable
                  transactions={filteredTransactions(overdueIssues)}
                  onReturn={openReturnDialog}
                  showReturnButton
                  showFine
                />
              </TabsContent>

              <TabsContent value="returned" className="mt-4">
                <TransactionTable transactions={filteredTransactions(returnedBooks)} />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </main>

      <IssueModal open={isIssueModalOpen} onOpenChange={setIsIssueModalOpen} onIssue={handleIssue} />

      <Dialog open={returnDialogOpen} onOpenChange={setReturnDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Return</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            {selectedTransaction && (
              <div className="space-y-2">
                <p>
                  <span className="font-medium">Book:</span>{" "}
                  {books.find((b) => b.id === selectedTransaction.bookId)?.title}
                </p>
                <p>
                  <span className="font-medium">Student:</span>{" "}
                  {students.find((s) => s.id === selectedTransaction.studentId)?.name}
                </p>
                <p>
                  <span className="font-medium">Due Date:</span> {selectedTransaction.dueDate}
                </p>
                {selectedTransaction.status === "overdue" && (
                  <p className="text-destructive">
                    <span className="font-medium">Fine:</span> ${calculateFine(selectedTransaction.dueDate)}
                  </p>
                )}
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setReturnDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleReturn}>Confirm Return</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

interface TransactionTableProps {
  transactions: Array<{
    id: string
    bookId: string
    studentId: string
    issueDate: string
    dueDate: string
    returnDate?: string
    status: string
    fine?: number
    book?: { title: string }
    student?: { name: string; studentId: string }
  }>
  onReturn?: (transaction: IssuedBook) => void
  showReturnButton?: boolean
  showFine?: boolean
}

function TransactionTable({ transactions, onReturn, showReturnButton, showFine }: TransactionTableProps) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b text-left text-sm text-muted-foreground">
            <th className="pb-3 font-medium">Book</th>
            <th className="pb-3 font-medium">Student</th>
            <th className="pb-3 font-medium">Issue Date</th>
            <th className="pb-3 font-medium">Due Date</th>
            <th className="pb-3 font-medium">Status</th>
            {showFine && <th className="pb-3 font-medium">Fine</th>}
            {showReturnButton && <th className="pb-3 font-medium">Action</th>}
          </tr>
        </thead>
        <tbody>
          {transactions.map((t) => (
            <tr key={t.id} className="border-b last:border-0">
              <td className="py-4 font-medium">{t.book?.title}</td>
              <td className="py-4">
                <div>
                  <p>{t.student?.name}</p>
                  <p className="text-xs text-muted-foreground">{t.student?.studentId}</p>
                </div>
              </td>
              <td className="py-4 text-muted-foreground">{t.issueDate}</td>
              <td className="py-4 text-muted-foreground">{t.dueDate}</td>
              <td className="py-4">
                <Badge
                  variant={t.status === "returned" ? "secondary" : t.status === "overdue" ? "destructive" : "default"}
                >
                  {t.status}
                </Badge>
              </td>
              {showFine && <td className="py-4 font-medium text-destructive">${t.fine || 0}</td>}
              {showReturnButton && onReturn && (
                <td className="py-4">
                  <Button size="sm" variant="outline" onClick={() => onReturn(t as IssuedBook)}>
                    Return
                  </Button>
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
      {transactions.length === 0 && (
        <div className="py-8 text-center text-muted-foreground">No transactions found.</div>
      )}
    </div>
  )
}
