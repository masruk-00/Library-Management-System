"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { BookModal } from "@/components/book-modal"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Plus, Search, MoreHorizontal, Edit, Trash2, Eye } from "lucide-react"
import { books as initialBooks, categories, type Book } from "@/lib/data"

export default function BooksPage() {
  const [booksList, setBooksList] = useState<Book[]>(initialBooks)
  const [searchQuery, setSearchQuery] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [selectedBook, setSelectedBook] = useState<Book | null>(null)

  const filteredBooks = booksList.filter((book) => {
    const matchesSearch =
      book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.isbn.includes(searchQuery)
    const matchesCategory = categoryFilter === "all" || book.category === categoryFilter
    return matchesSearch && matchesCategory
  })

  const handleAddBook = () => {
    setSelectedBook(null)
    setIsModalOpen(true)
  }

  const handleEditBook = (book: Book) => {
    setSelectedBook(book)
    setIsModalOpen(true)
  }

  const handleDeleteBook = (bookId: string) => {
    setBooksList(booksList.filter((b) => b.id !== bookId))
  }

  const handleSaveBook = (bookData: Partial<Book>) => {
    if (selectedBook) {
      setBooksList(booksList.map((b) => (b.id === selectedBook.id ? { ...b, ...bookData } : b)))
    } else {
      const newBook: Book = {
        id: (booksList.length + 1).toString(),
        title: bookData.title || "",
        author: bookData.author || "",
        category: bookData.category || "",
        isbn: bookData.isbn || "",
        quantity: bookData.quantity || 0,
        available: bookData.available || 0,
        status: "available",
        publishedYear: bookData.publishedYear || 2024,
        description: bookData.description,
      }
      setBooksList([...booksList, newBook])
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "available":
        return "default"
      case "low-stock":
        return "secondary"
      case "unavailable":
        return "destructive"
      default:
        return "default"
    }
  }

  return (
    <div className="min-h-screen">
      <Header title="Book Management" />

      <main className="p-6">
        <Card>
          <CardContent className="p-6">
            <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex flex-1 flex-col gap-4 sm:flex-row">
                <div className="relative flex-1 sm:max-w-xs">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search books..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="w-full sm:w-44">
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map((cat) => (
                      <SelectItem key={cat} value={cat}>
                        {cat}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={handleAddBook}>
                <Plus className="mr-2 h-4 w-4" />
                Add Book
              </Button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b text-left text-sm text-muted-foreground">
                    <th className="pb-3 font-medium">Title</th>
                    <th className="pb-3 font-medium">Author</th>
                    <th className="pb-3 font-medium">Category</th>
                    <th className="pb-3 font-medium">ISBN</th>
                    <th className="pb-3 font-medium">Qty</th>
                    <th className="pb-3 font-medium">Available</th>
                    <th className="pb-3 font-medium">Status</th>
                    <th className="pb-3 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredBooks.map((book) => (
                    <tr key={book.id} className="border-b last:border-0">
                      <td className="py-4 font-medium">{book.title}</td>
                      <td className="py-4 text-muted-foreground">{book.author}</td>
                      <td className="py-4 text-muted-foreground">{book.category}</td>
                      <td className="py-4 font-mono text-sm text-muted-foreground">{book.isbn}</td>
                      <td className="py-4 text-center">{book.quantity}</td>
                      <td className="py-4 text-center">{book.available}</td>
                      <td className="py-4">
                        <Badge variant={getStatusColor(book.status)}>
                          {book.status === "low-stock"
                            ? "Low Stock"
                            : book.status === "unavailable"
                              ? "Unavailable"
                              : "Available"}
                        </Badge>
                      </td>
                      <td className="py-4">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Eye className="mr-2 h-4 w-4" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleEditBook(book)}>
                              <Edit className="mr-2 h-4 w-4" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-destructive" onClick={() => handleDeleteBook(book.id)}>
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {filteredBooks.length === 0 && (
              <div className="py-12 text-center text-muted-foreground">No books found matching your criteria.</div>
            )}
          </CardContent>
        </Card>
      </main>

      <BookModal open={isModalOpen} onOpenChange={setIsModalOpen} book={selectedBook} onSave={handleSaveBook} />
    </div>
  )
}
