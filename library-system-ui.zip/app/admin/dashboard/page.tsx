"use client"

import { Header } from "@/components/header"
import { StatCard } from "@/components/stat-card"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BookOpen, BookCopy, CheckCircle, Users, AlertTriangle, DollarSign, TrendingUp, Clock } from "lucide-react"
import { dashboardStats, monthlyStats, categoryDistribution, issuedBooks, books, students } from "@/lib/data"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts"
import { Badge } from "@/components/ui/badge"

const COLORS = [
  "hsl(var(--chart-1))",
  "hsl(var(--chart-2))",
  "hsl(var(--chart-3))",
  "hsl(var(--chart-4))",
  "hsl(var(--chart-5))",
  "hsl(var(--muted))",
]

export default function AdminDashboardPage() {
  const recentTransactions = issuedBooks
    .map((issue) => ({
      ...issue,
      book: books.find((b) => b.id === issue.bookId),
      student: students.find((s) => s.id === issue.studentId),
    }))
    .slice(0, 5)

  return (
    <div className="min-h-screen">
      <Header title="Dashboard" />

      <main className="p-6">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Total Books"
            value={dashboardStats.totalBooks}
            icon={BookOpen}
            trend={{ value: 12, isPositive: true }}
            iconClassName="bg-primary"
          />
          <StatCard
            title="Issued Books"
            value={dashboardStats.issuedBooks}
            icon={BookCopy}
            trend={{ value: 8, isPositive: true }}
            iconClassName="bg-chart-2"
          />
          <StatCard
            title="Available Books"
            value={dashboardStats.availableBooks}
            icon={CheckCircle}
            iconClassName="bg-success"
          />
          <StatCard
            title="Registered Members"
            value={dashboardStats.registeredMembers}
            icon={Users}
            trend={{ value: 5, isPositive: true }}
            iconClassName="bg-chart-4"
          />
        </div>

        <div className="mt-6 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Overdue Books"
            value={dashboardStats.overdueBooks}
            icon={AlertTriangle}
            iconClassName="bg-destructive"
          />
          <StatCard
            title="Total Fines"
            value={`$${dashboardStats.totalFines}`}
            icon={DollarSign}
            iconClassName="bg-warning"
          />
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Monthly Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={monthlyStats}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="month" className="text-xs" />
                    <YAxis className="text-xs" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px",
                      }}
                    />
                    <Bar dataKey="issued" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="returned" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-4 flex justify-center gap-6">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-chart-1" />
                  <span className="text-sm text-muted-foreground">Issued</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-chart-2" />
                  <span className="text-sm text-muted-foreground">Returned</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5 text-primary" />
                Books by Category
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={categoryDistribution}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={2}
                      dataKey="count"
                    >
                      {categoryDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px",
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-4 flex flex-wrap justify-center gap-4">
                {categoryDistribution.slice(0, 4).map((item, index) => (
                  <div key={item.category} className="flex items-center gap-2">
                    <div className="h-3 w-3 rounded-full" style={{ backgroundColor: COLORS[index] }} />
                    <span className="text-xs text-muted-foreground">{item.category}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-primary" />
              Recent Transactions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b text-left text-sm text-muted-foreground">
                    <th className="pb-3 font-medium">Book</th>
                    <th className="pb-3 font-medium">Student</th>
                    <th className="pb-3 font-medium">Issue Date</th>
                    <th className="pb-3 font-medium">Due Date</th>
                    <th className="pb-3 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {recentTransactions.map((transaction) => (
                    <tr key={transaction.id} className="border-b last:border-0">
                      <td className="py-4 font-medium">{transaction.book?.title}</td>
                      <td className="py-4 text-muted-foreground">{transaction.student?.name}</td>
                      <td className="py-4 text-muted-foreground">{transaction.issueDate}</td>
                      <td className="py-4 text-muted-foreground">{transaction.dueDate}</td>
                      <td className="py-4">
                        <Badge
                          variant={
                            transaction.status === "returned"
                              ? "secondary"
                              : transaction.status === "overdue"
                                ? "destructive"
                                : "default"
                          }
                        >
                          {transaction.status}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
