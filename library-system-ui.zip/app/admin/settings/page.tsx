"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { Settings, Bell, DollarSign, Clock, Save } from "lucide-react"

export default function SettingsPage() {
  const [settings, setSettings] = useState({
    libraryName: "University Central Library",
    email: "library@university.edu",
    phone: "+1 (555) 123-4567",
    address: "123 University Ave, Campus Building A",
    loanPeriod: "14",
    maxBooks: "5",
    finePerDay: "5",
    renewalLimit: "2",
    emailNotifications: true,
    overdueReminders: true,
    dueDateAlerts: true,
    newBookAlerts: false,
  })

  const handleSave = () => {
    // Save settings logic would go here
    console.log("Settings saved:", settings)
  }

  return (
    <div className="min-h-screen">
      <Header title="Settings" />

      <main className="p-6">
        <div className="mx-auto max-w-3xl space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Library Information
              </CardTitle>
              <CardDescription>Basic information about your library</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="libraryName">Library Name</Label>
                  <Input
                    id="libraryName"
                    value={settings.libraryName}
                    onChange={(e) => setSettings({ ...settings, libraryName: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={settings.email}
                    onChange={(e) => setSettings({ ...settings, email: e.target.value })}
                  />
                </div>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    value={settings.phone}
                    onChange={(e) => setSettings({ ...settings, phone: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="address">Address</Label>
                  <Input
                    id="address"
                    value={settings.address}
                    onChange={(e) => setSettings({ ...settings, address: e.target.value })}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Loan Settings
              </CardTitle>
              <CardDescription>Configure book lending policies</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="loanPeriod">Loan Period (days)</Label>
                  <Input
                    id="loanPeriod"
                    type="number"
                    value={settings.loanPeriod}
                    onChange={(e) => setSettings({ ...settings, loanPeriod: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="maxBooks">Max Books Per Student</Label>
                  <Input
                    id="maxBooks"
                    type="number"
                    value={settings.maxBooks}
                    onChange={(e) => setSettings({ ...settings, maxBooks: e.target.value })}
                  />
                </div>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="renewalLimit">Renewal Limit</Label>
                  <Input
                    id="renewalLimit"
                    type="number"
                    value={settings.renewalLimit}
                    onChange={(e) => setSettings({ ...settings, renewalLimit: e.target.value })}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Fine Settings
              </CardTitle>
              <CardDescription>Configure overdue fine policies</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="max-w-xs space-y-2">
                <Label htmlFor="finePerDay">Fine Per Day ($)</Label>
                <Input
                  id="finePerDay"
                  type="number"
                  value={settings.finePerDay}
                  onChange={(e) => setSettings({ ...settings, finePerDay: e.target.value })}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5" />
                Notifications
              </CardTitle>
              <CardDescription>Manage notification preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Email Notifications</p>
                  <p className="text-sm text-muted-foreground">Receive email notifications for important events</p>
                </div>
                <Switch
                  checked={settings.emailNotifications}
                  onCheckedChange={(checked) => setSettings({ ...settings, emailNotifications: checked })}
                />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Overdue Reminders</p>
                  <p className="text-sm text-muted-foreground">Send reminders for overdue books</p>
                </div>
                <Switch
                  checked={settings.overdueReminders}
                  onCheckedChange={(checked) => setSettings({ ...settings, overdueReminders: checked })}
                />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Due Date Alerts</p>
                  <p className="text-sm text-muted-foreground">Alert students before due date</p>
                </div>
                <Switch
                  checked={settings.dueDateAlerts}
                  onCheckedChange={(checked) => setSettings({ ...settings, dueDateAlerts: checked })}
                />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">New Book Alerts</p>
                  <p className="text-sm text-muted-foreground">Notify students about new arrivals</p>
                </div>
                <Switch
                  checked={settings.newBookAlerts}
                  onCheckedChange={(checked) => setSettings({ ...settings, newBookAlerts: checked })}
                />
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end">
            <Button onClick={handleSave}>
              <Save className="mr-2 h-4 w-4" />
              Save Changes
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}
