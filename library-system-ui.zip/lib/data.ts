// Mock data for the Library Management System

export interface Book {
  id: string
  title: string
  author: string
  category: string
  isbn: string
  quantity: number
  available: number
  status: "available" | "low-stock" | "unavailable"
  coverImage?: string
  publishedYear: number
  description?: string
}

export interface Student {
  id: string
  name: string
  email: string
  studentId: string
  department: string
  semester: number
  joinedDate: string
  avatar?: string
}

export interface IssuedBook {
  id: string
  bookId: string
  studentId: string
  issueDate: string
  dueDate: string
  returnDate?: string
  status: "issued" | "returned" | "overdue"
  fine?: number
}

export const books: Book[] = [
  {
    id: "1",
    title: "Introduction to Algorithms",
    author: "Thomas H. Cormen",
    category: "Computer Science",
    isbn: "978-0262033848",
    quantity: 10,
    available: 6,
    status: "available",
    publishedYear: 2009,
    description: "A comprehensive textbook on computer algorithms.",
  },
  {
    id: "2",
    title: "Clean Code",
    author: "Robert C. Martin",
    category: "Software Engineering",
    isbn: "978-0132350884",
    quantity: 8,
    available: 2,
    status: "low-stock",
    publishedYear: 2008,
    description: "A handbook of agile software craftsmanship.",
  },
  {
    id: "3",
    title: "Design Patterns",
    author: "Gang of Four",
    category: "Software Engineering",
    isbn: "978-0201633610",
    quantity: 5,
    available: 0,
    status: "unavailable",
    publishedYear: 1994,
    description: "Elements of reusable object-oriented software.",
  },
  {
    id: "4",
    title: "Database System Concepts",
    author: "Abraham Silberschatz",
    category: "Database",
    isbn: "978-0073523323",
    quantity: 12,
    available: 8,
    status: "available",
    publishedYear: 2019,
    description: "Comprehensive introduction to database systems.",
  },
  {
    id: "5",
    title: "Computer Networks",
    author: "Andrew S. Tanenbaum",
    category: "Networking",
    isbn: "978-0132126953",
    quantity: 7,
    available: 5,
    status: "available",
    publishedYear: 2010,
    description: "A top-down approach to computer networking.",
  },
  {
    id: "6",
    title: "Operating System Concepts",
    author: "Abraham Silberschatz",
    category: "Operating Systems",
    isbn: "978-1118063330",
    quantity: 9,
    available: 3,
    status: "low-stock",
    publishedYear: 2012,
    description: "Fundamental concepts of operating systems.",
  },
  {
    id: "7",
    title: "Artificial Intelligence: A Modern Approach",
    author: "Stuart Russell",
    category: "Artificial Intelligence",
    isbn: "978-0136042594",
    quantity: 6,
    available: 4,
    status: "available",
    publishedYear: 2020,
    description: "The leading textbook in Artificial Intelligence.",
  },
  {
    id: "8",
    title: "The Pragmatic Programmer",
    author: "David Thomas",
    category: "Software Engineering",
    isbn: "978-0135957059",
    quantity: 4,
    available: 1,
    status: "low-stock",
    publishedYear: 2019,
    description: "Your journey to mastery in software development.",
  },
]

export const students: Student[] = [
  {
    id: "1",
    name: "Alice Johnson",
    email: "alice.johnson@university.edu",
    studentId: "STU001",
    department: "Computer Science",
    semester: 6,
    joinedDate: "2022-08-15",
  },
  {
    id: "2",
    name: "Bob Smith",
    email: "bob.smith@university.edu",
    studentId: "STU002",
    department: "Information Technology",
    semester: 4,
    joinedDate: "2023-01-10",
  },
  {
    id: "3",
    name: "Carol Williams",
    email: "carol.williams@university.edu",
    studentId: "STU003",
    department: "Computer Science",
    semester: 8,
    joinedDate: "2021-08-20",
  },
  {
    id: "4",
    name: "David Brown",
    email: "david.brown@university.edu",
    studentId: "STU004",
    department: "Electronics",
    semester: 2,
    joinedDate: "2024-01-05",
  },
  {
    id: "5",
    name: "Eva Martinez",
    email: "eva.martinez@university.edu",
    studentId: "STU005",
    department: "Computer Science",
    semester: 6,
    joinedDate: "2022-08-15",
  },
]

export const issuedBooks: IssuedBook[] = [
  {
    id: "1",
    bookId: "1",
    studentId: "1",
    issueDate: "2025-01-01",
    dueDate: "2025-01-15",
    status: "issued",
  },
  {
    id: "2",
    bookId: "2",
    studentId: "2",
    issueDate: "2024-12-20",
    dueDate: "2025-01-03",
    status: "overdue",
    fine: 55,
  },
  {
    id: "3",
    bookId: "4",
    studentId: "3",
    issueDate: "2025-01-05",
    dueDate: "2025-01-19",
    status: "issued",
  },
  {
    id: "4",
    bookId: "5",
    studentId: "1",
    issueDate: "2024-12-15",
    dueDate: "2024-12-29",
    returnDate: "2024-12-28",
    status: "returned",
  },
  {
    id: "5",
    bookId: "6",
    studentId: "4",
    issueDate: "2024-12-25",
    dueDate: "2025-01-08",
    status: "overdue",
    fine: 30,
  },
  {
    id: "6",
    bookId: "7",
    studentId: "5",
    issueDate: "2025-01-10",
    dueDate: "2025-01-24",
    status: "issued",
  },
]

export const categories = [
  "Computer Science",
  "Software Engineering",
  "Database",
  "Networking",
  "Operating Systems",
  "Artificial Intelligence",
  "Mathematics",
  "Physics",
  "Electronics",
]

export const dashboardStats = {
  totalBooks: 61,
  issuedBooks: 18,
  availableBooks: 43,
  registeredMembers: 156,
  overdueBooks: 5,
  totalFines: 425,
}

export const monthlyStats = [
  { month: "Aug", issued: 45, returned: 38 },
  { month: "Sep", issued: 62, returned: 55 },
  { month: "Oct", issued: 58, returned: 52 },
  { month: "Nov", issued: 71, returned: 65 },
  { month: "Dec", issued: 48, returned: 42 },
  { month: "Jan", issued: 35, returned: 28 },
]

export const categoryDistribution = [
  { category: "Computer Science", count: 18 },
  { category: "Software Engineering", count: 12 },
  { category: "Database", count: 8 },
  { category: "Networking", count: 6 },
  { category: "AI & ML", count: 10 },
  { category: "Others", count: 7 },
]
