"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import {
  BookOpen,
  LayoutDashboard,
  Users,
  BookCopy,
  ArrowLeftRight,
  BarChart3,
  Settings,
  LogOut,
  Library,
  GraduationCap,
} from "lucide-react"
import { Button } from "@/components/ui/button"

interface SidebarProps {
  userType: "admin" | "student"
}

const adminNavItems = [
  { href: "/admin/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/admin/books", label: "Books", icon: BookOpen },
  { href: "/admin/issue-return", label: "Issue & Return", icon: ArrowLeftRight },
  { href: "/admin/students", label: "Students", icon: Users },
  { href: "/admin/reports", label: "Reports", icon: BarChart3 },
  { href: "/admin/settings", label: "Settings", icon: Settings },
]

const studentNavItems = [
  { href: "/student/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/student/browse", label: "Browse Books", icon: BookOpen },
  { href: "/student/my-books", label: "My Books", icon: BookCopy },
  { href: "/student/profile", label: "Profile", icon: GraduationCap },
]

export function Sidebar({ userType }: SidebarProps) {
  const pathname = usePathname()
  const navItems = userType === "admin" ? adminNavItems : studentNavItems

  return (
    <aside className="fixed left-0 top-0 z-40 h-screen w-64 bg-sidebar text-sidebar-foreground">
      <div className="flex h-full flex-col">
        <div className="flex h-16 items-center gap-2 border-b border-sidebar-border px-6">
          <Library className="h-8 w-8 text-sidebar-primary" />
          <span className="text-xl font-bold">LibraryHub</span>
        </div>

        <nav className="flex-1 space-y-1 p-4">
          {navItems.map((item) => {
            const isActive = pathname === item.href
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                  isActive
                    ? "bg-sidebar-accent text-sidebar-primary"
                    : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground",
                )}
              >
                <item.icon className="h-5 w-5" />
                {item.label}
              </Link>
            )
          })}
        </nav>

        <div className="border-t border-sidebar-border p-4">
          <div className="mb-4 flex items-center gap-3 px-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-sidebar-accent">
              <span className="text-sm font-medium">{userType === "admin" ? "AD" : "ST"}</span>
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium">{userType === "admin" ? "Admin User" : "Student User"}</p>
              <p className="text-xs text-sidebar-foreground/60">
                {userType === "admin" ? "admin@library.edu" : "student@university.edu"}
              </p>
            </div>
          </div>
          <Button
            variant="ghost"
            className="w-full justify-start gap-3 text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
            asChild
          >
            <Link href="/">
              <LogOut className="h-5 w-5" />
              Sign Out
            </Link>
          </Button>
        </div>
      </div>
    </aside>
  )
}
